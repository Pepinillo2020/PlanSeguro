interface Usuario {
    _id?: string;
    nombre: string;
    email: string;
    telefono: string;
    contrasena: string;
    rol: string;
  }