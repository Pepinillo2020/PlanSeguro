interface Comentario {
    _id?: string;
    incidente: string;
    usuario: string;
    texto: string;
    fecha: Date;
  }